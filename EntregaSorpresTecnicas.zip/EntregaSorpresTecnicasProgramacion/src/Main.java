import app.Applicaciones;
import factories.DialogFactory;
import factories.DialogMacFactory;
import factories.DialogWindowsFactory;

public class Main {
    private static Applicaciones configureApplication() {
        Applicaciones app;
        DialogFactory factory;
        String osName = System.getProperty("os.name").toLowerCase();
        if (osName.contains("mac")) {
            factory = new DialogMacFactory();
            factory.crearDialogo();
        } else {
            factory = new DialogWindowsFactory();
            factory.crearDialogo();
        }
        app = new Applicaciones(factory);
        return app;
    }

    public static void main(String[] args) {
        Applicaciones app = configureApplication();
        app.paint();
    }
}
