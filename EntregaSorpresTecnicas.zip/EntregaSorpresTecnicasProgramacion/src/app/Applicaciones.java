package app;

import dialogos.Dialogo;
import factories.DialogFactory;

public class Applicaciones {
    private Dialogo dialologo;

    public Applicaciones(DialogFactory factory){
        dialologo = factory.crearDialogo();
    }

    public void paint(){
        dialologo.mostrarDialogo();
    }
}
