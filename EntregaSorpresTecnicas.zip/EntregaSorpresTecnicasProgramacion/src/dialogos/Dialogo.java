package dialogos;

public interface Dialogo {
    void mostrarDialogo();
}
