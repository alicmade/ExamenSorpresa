
package dialogos;

public class DialogoMac implements Dialogo {
    @Override
    public void mostrarDialogo() {

        System.out.println("Dialogo de Mac");
    }
}
