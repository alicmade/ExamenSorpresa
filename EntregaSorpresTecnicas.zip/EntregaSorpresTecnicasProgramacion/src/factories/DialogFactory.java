package factories;

import dialogos.Dialogo;

public interface DialogFactory {
    Dialogo crearDialogo();
}
