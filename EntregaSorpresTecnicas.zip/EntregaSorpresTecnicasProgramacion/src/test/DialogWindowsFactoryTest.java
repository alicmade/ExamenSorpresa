package test;

import dialogos.Dialogo;
import dialogos.DialogoWindows;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DialogWindowsFactoryTest extends DialogoWindows {
    @Test
    void  crearDialogo() {
    }
}