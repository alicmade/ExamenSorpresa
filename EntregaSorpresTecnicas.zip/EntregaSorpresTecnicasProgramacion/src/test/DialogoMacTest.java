package test;

import dialogos.DialogoWindows;

import static org.junit.jupiter.api.Assertions.*;

class DialogoMacTest extends DialogoWindows {

    @org.junit.jupiter.api.Test
    void testMostrarDialogo() {

    }
}