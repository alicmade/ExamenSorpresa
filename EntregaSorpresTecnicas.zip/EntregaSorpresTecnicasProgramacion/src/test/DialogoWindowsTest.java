package test;

import dialogos.DialogoWindows;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DialogoWindowsTest extends DialogoWindows {

    @Test
    void testMostrarDialogo() {

    }
}